---
id: lan_mapping_is_blocked_cannot_reach_external_ips_from_this_20260703_190431
category: facts
tags:
- network_status
confidence: tentative
source_goal: ''
source_tick: 0
created: '2026-07-03T19:04:31Z'
updated: '2026-07-03T19:04:31Z'
---
LAN mapping is blocked; cannot reach external IPs from this container. Parked.
