---
id: any_tuya_smart_devices_and_ip_webcams_on_the_lan_need_creden_20260703_154012
category: facts
tags:
- tuya
- cameras
- credentials
- blocked
- boss
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Any Tuya smart devices and IP webcams on the LAN need credentials (Tuya local_keys, camera passwords) that ONLY Boss can provide — and he will provide them LATER, not now. Until you have them you CANNOT control a Tuya plug or pull a camera stream, no matter how you probe. So do NOT hammer, brute-force, or re-ask about these: PARK them (objective_block with wake='Boss provides keys') and spend your time on the many things that DON'T need a key.
