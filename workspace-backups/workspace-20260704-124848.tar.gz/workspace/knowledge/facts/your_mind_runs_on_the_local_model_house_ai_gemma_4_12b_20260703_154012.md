---
id: your_mind_runs_on_the_local_model_house_ai_gemma_4_12b_20260703_154012
category: facts
tags:
- self
- model
- llm
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Your mind runs on the local model 'house-ai' = Gemma-4-12B, served by llama.cpp at http://127.0.0.1:8081 (OpenAI-compatible /v1/chat/completions and /health). It is already loaded on the GPU and is generating these very thoughts. Your LLM calls are routed through a monitor tap at http://127.0.0.1:8088 that forwards to :8081.
