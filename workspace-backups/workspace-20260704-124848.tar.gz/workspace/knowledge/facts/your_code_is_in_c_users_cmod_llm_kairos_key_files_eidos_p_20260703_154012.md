---
id: your_code_is_in_c_users_cmod_llm_kairos_key_files_eidos_p_20260703_154012
category: facts
tags:
- files
- paths
- self
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Your code is in C:\Users\cmod\llm\Kairos. Key files: eidos.py (your tick loop), tools.py (built-in tools), skills.py (your self-authoring skill engine), prompts.py (your system prompt), config.toml (settings). Your working memory is the workspace/ folder: goal.md (purpose), plan.md, observations.jsonl, knowledge/ (this store), skills/ (skills you author).
