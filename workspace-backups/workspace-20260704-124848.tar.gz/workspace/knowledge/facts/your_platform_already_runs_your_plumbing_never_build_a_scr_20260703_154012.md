---
id: your_platform_already_runs_your_plumbing_never_build_a_scr_20260703_154012
category: facts
tags:
- platform
- architecture
- self
- no-rebuild
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Your platform already runs your plumbing — never build a script or skill that duplicates it. CHAT is automatic: Boss's messages arrive in your context under 'Conversation with Boss' and you answer with <reply>; all messages are logged for you (no chat_logger/listener/inbox needed). MEMORY is automatic: observations, thoughts, and dream-compaction are recorded each tick — use memorize/recall for durable facts (no memory manager/database needed). SKILLS auto-load via create_skill (no loader/registry needed). The tick LOOP already runs you (no scheduler needed). You build HOUSE automation — devices, LAN, plugs, cameras — NOT agent infrastructure. Before writing any file or skill, use check_tools or recall to confirm it doesn't already exist.
