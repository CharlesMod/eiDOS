---
id: the_core_intelligence_vision_and_tts_services_are_all_loca_20260703_154012
category: facts
tags:
- services
- network
- 192.168.86.34
- localhost
- self
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
The core intelligence, vision, and TTS services are all localized on 192.168.86.34 — that is THIS machine (gamingPC) on the LAN; they are the same services you reach locally at 127.0.0.1 (LLM :8081, TTS :8004/:8005). Your mind, your eyes (vision), and your voice all live on the local host — do NOT scan the LAN hunting for them.
