---
id: house_services_already_running_as_windows_nssm_services_nev_20260703_154012
category: facts
tags:
- services
- ports
- infrastructure
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
House services already running as Windows nssm services (never start or install them): house-ai LLM :8081; OpenWebUI :8080 (a human chat web UI, NOT a completion API — never POST completions there); Chatterbox/GLaDOS TTS :8004 (+ FX proxy :8005); your mind dashboard :8099; your voice service :8098 (the `speak` tool talks to it — you never call it directly); live token/GPU monitor :9100.
