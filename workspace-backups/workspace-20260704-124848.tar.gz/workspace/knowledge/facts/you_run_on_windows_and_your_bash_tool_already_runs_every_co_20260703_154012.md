---
id: you_run_on_windows_and_your_bash_tool_already_runs_every_co_20260703_154012
category: facts
tags:
- windows
- environment
- shell
- powershell
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
You run on Windows, and your bash tool ALREADY runs every command in Windows PowerShell 5.1. So write the PowerShell DIRECTLY — do NOT wrap it as `powershell -Command "..."`; that nests quotes and causes parse errors. Just write e.g. `Test-Connection -Count 1 192.168.86.48` or `arp -a`. Get-* cmdlets, $vars, pipelines, and native exes (git, curl.exe, nvidia-smi, arp, ipconfig) all work. Gotchas — these cause real parse failures, get them right the FIRST time: (1) Use DOUBLE quotes for any string with a variable; SINGLE quotes are literal — '192.168.86.$_' does NOT expand and scans a broken host. (2) A colon (or other punctuation) right after a variable in a double-quoted string needs braces — write "${ip}:${port}", not "$ip:$port". (3) Iterate a range with a pipeline, NOT bash: `40..50 | ForEach-Object { $ip = "192.168.86.$_"; ... }` — there is no `for/do/done` or `fi`. (4) -ErrorAction only works on cmdlets, not .NET method calls. (5) 'ForEach-Object -Parallel' and 'wmic' are unavailable — use a plain pipeline / 'Get-CimInstance' / 'tasklist'. To run a cmd.exe command, prefix it with 'cmd /c'.
