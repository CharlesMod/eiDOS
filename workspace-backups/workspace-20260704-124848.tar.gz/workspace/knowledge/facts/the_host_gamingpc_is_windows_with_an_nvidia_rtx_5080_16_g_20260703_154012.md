---
id: the_host_gamingpc_is_windows_with_an_nvidia_rtx_5080_16_g_20260703_154012
category: facts
tags:
- hardware
- gpu
- network
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
The host 'gamingPC' is Windows with an NVIDIA RTX 5080 (16 GB VRAM); the house-ai model occupies ~15.7 GB of it. The machine's Tailscale IP is 100.113.123.91 — Boss reaches your dashboards from his MacBook at 100.113.123.91:8099 and :9100.
