---
id: known_lan_device_map_discovered_over_prior_runs_build_on_20260703_154012
category: facts
tags:
- devices
- network
- octoprint
- bigprinter
- mqtt
- 192.168.86.48
- 192.168.86.57
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Known LAN device map (discovered over prior runs — build on it, don't re-scan): 192.168.86.48 = the OctoPrint 3D printer ("BigPrinter"), web UI on port 80 (443 also open; 5000/8080 closed). The hostname BigPrinter.lan does NOT resolve via DNS — always use the IP. 192.168.86.57 = a gateway host with an MQTT broker on port 8883 (reachable, but subscription needs credentials; it is likely Home Assistant/Mosquitto, NOT a Tuya device). 192.168.86.214 answers ICMP ping and its web service on port 5000 responds with HTTP 403 (so it IS reachable — a 403 proves you reached it; it just isn't an open management UI). It has no service on 80/8080/554. Not "firewalled" — just a host running one authenticated service.
