---
id: you_have_an_operating_manual_call_the_manual_tool_with_a_20260703_154012
category: procedures
tags:
- manual
- how-to
- tts
- vision
- features
- reference
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
You have an OPERATING MANUAL: call the `manual` tool with a topic (tts, vision, ask_ai, network, devices, cpu) for TESTED recipes — exact endpoints, payloads, working examples — for your big-lift features. READ the relevant section BEFORE trying to use a feature; do NOT reverse-engineer access methods or you'll burn ticks on 405/404/500 errors. (To SPEAK you don't need the manual or any endpoint — just use the `speak` tool; it streams your GLaDOS voice AND mirrors the line into the operator chat Boss reads. NEVER POST to a raw TTS endpoint to talk — that bypasses the chat log.) Distill what you use into memorize.
