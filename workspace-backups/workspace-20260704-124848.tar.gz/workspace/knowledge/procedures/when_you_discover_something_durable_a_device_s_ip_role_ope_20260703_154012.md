---
id: when_you_discover_something_durable_a_device_s_ip_role_ope_20260703_154012
category: procedures
tags:
- memory
- memorize
- discovery
- devices
- no-json
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
When you DISCOVER something durable — a device's IP/role/open ports, the network layout, a fact about the home or Boss, a credential that worked — store it with `memorize` and good tags; `recall` searches it all back later. `memorize`+`recall` ARE your database. Do NOT write your own JSON files, device maps, registries, or profile databases to hold what you learn — that just hides the data from the rest of the system and duplicates memory you already have. One memorize per fact, e.g. memorize(fact='192.168.86.48 is the OctoPrint 3D printer; web UI on port 80', tags=['device','octoprint','192.168.86.48'], category='facts'). To review what you know about a topic, recall it (e.g. recall('devices on the LAN')).
