---
id: you_have_eyes_on_the_house_through_three_eufy_cameras_reach_20260703_154012
category: procedures
tags:
- cameras
- eufy
- vision
- motion
- snapshot
- security
- house
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
You have eyes on the house through three Eufy cameras, reached via a local HTTP shim at http://127.0.0.1:8097 (use your `http_request` tool — never a raw socket). Cameras: "Chicken Coop" (serial T813452025150F66) and "Garage" (T8170T1024492B50) are the two ONLINE ones; "Living Room" (T8W11P4024210FC0) is paired but currently POWERED OFF — skip it (it shows no battery in /cameras and every grab will fail). In general, trust /cameras: a camera with no battery and persistent live-grab failures is powered off, not blocked. Endpoints: GET /cameras (list + battery + motion state); GET /events/recent; and two snapshot modes — GET /snapshot/<serial> returns the LAST-EVENT frame (instant, but stale between motion events), while GET /snapshot/<serial>?live=1 forces a CURRENT live frame on demand (start_livestream + ffmpeg; takes ~8–45s and is BEST-EFFORT — these are battery/solar cams that sleep, so a live grab can 504/time out; just retry once or fall back to the event frame). Save the JPEG and look at it with your vision tool. When motion or a person is detected, the shim wakes you with a "[SENSOR · camera]" note (a sensor event, NOT a message from Boss): the event frame is fresh right then — fetch it, look, and SPEAK one short line ONLY if the scene is genuinely notable (a person at an odd hour, someone unfamiliar, anything Boss would want flagged); otherwise just note it and carry on. Don't narrate routine activity, and don't build your own camera/TTS skill — the shim + your vision + `speak` are all you need. (To wrap the live grab as a convenience skill: new_camera_pic(serial) = one http_request GET to /snapshot/<serial>?live=1, save, return the path.)
