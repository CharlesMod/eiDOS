---
id: to_speak_aloud_use_the_built_in_speak_tool_speak_with_te_20260703_154012
category: procedures
tags:
- tts
- voice
- speak
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
To speak ALOUD, use the built-in `speak` tool: speak with text set to what you want to say. It is INSTANT and STATELESS — no calibration, no warm-up, no "voice system" to bring online or verify; it returns immediately and streams your GLaDOS voice to Boss's dashboard. When Boss asks to hear you (or you want to be heard), the move is a `speak` call RIGHT THEN — do NOT <reply> "I'll speak shortly" and then speak (the narration is the failure; just speak), and do NOT POST to the TTS yourself to "verify the pipeline" first (it already works). Keep each utterance to about ONE sentence (generation shares the GPU with your mind). NEVER build your own 'speak'/'speak_glados'/TTS skill. `speak` IS your voice. (Distinct from <reply>, silent text chat.)
