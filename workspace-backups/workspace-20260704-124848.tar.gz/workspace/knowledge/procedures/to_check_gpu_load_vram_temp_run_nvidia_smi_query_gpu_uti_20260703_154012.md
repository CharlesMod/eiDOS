---
id: to_check_gpu_load_vram_temp_run_nvidia_smi_query_gpu_uti_20260703_154012
category: procedures
tags:
- gpu
- monitor
- check
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
To check GPU load/VRAM/temp, run: nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw --format=csv,noheader . Utilization near 0 between your ticks is normal; it only spikes during generation.
