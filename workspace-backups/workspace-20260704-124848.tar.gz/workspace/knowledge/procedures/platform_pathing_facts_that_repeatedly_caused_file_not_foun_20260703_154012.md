---
id: platform_pathing_facts_that_repeatedly_caused_file_not_foun_20260703_154012
category: procedures
tags:
- skills
- versioning
- self-edit
- pathing
- workspace
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Platform pathing facts that repeatedly caused 'file not found' confusion: your skill source files live in C:\Users\cmod\llm\Kairos\workspace\skills\ named with DOUBLE underscores and a version — e.g. soft_fail_executor__1.0.7.py — there is no bare soft_fail_executor.py. You never edit those files directly: edit_skill(name, code) creates the next version for you. propose_self_edit is ONLY for repo source files (repo-relative paths like prompts.py) and CANNOT target skills, dashboard.py, config, or safety files. Use absolute paths anchored at C:\Users\cmod\llm\Kairos\workspace for any file operation in bash.
