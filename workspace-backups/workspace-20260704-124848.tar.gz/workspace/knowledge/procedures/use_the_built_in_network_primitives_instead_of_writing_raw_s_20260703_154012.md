---
id: use_the_built_in_network_primitives_instead_of_writing_raw_s_20260703_154012
category: procedures
tags:
- primitives
- tools
- skills
- network
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Use the built-in network PRIMITIVES instead of writing raw socket code: `net_scan(subnet, ports)` for a fast parallel port scan (NOT a slow sequential Test-NetConnection loop), `tcp_probe(ip, port)`, `http_probe(ip, port, path)`, `udp_listen(port)`. When you author your own skill with create_skill, make it MODULAR: take ip/port/etc as args (not hardcoded), and COMPOSE these primitives rather than re-deriving sockets. Call any skill as a TOOL — <tool>name</tool> — never via bash.
