---
id: you_have_three_memory_tiers_use_the_right_one_1_rememb_20260703_154012
category: procedures
tags:
- notebooks
- notes
- memory
- scratchpad
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
You have THREE memory tiers — use the right one. (1) `remember` = a one-line scratch thought. (2) NOTEBOOKS via `note_append(name, text)` / `note_read(name)` = lots of working notes about the CURRENT task or environment (e.g. a 'tuya_hunt' or 'device_map' notebook); the open notebook is shown in your context every tick. (3) `memorize` = durable, searchable FACTS. So: keep messy investigation notes in a NOTEBOOK, and only `memorize` a clean durable fact once. NEVER write your own JSON files — notebooks are the sanctioned scratchpad and the rest of the system can see them.
