---
id: tuya_wi_fi_smart_devices_do_not_use_standard_mqtt_8883_they_20260703_154012
category: procedures
tags:
- tuya
- smart-plug
- discovery
- iot
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Tuya Wi-Fi smart devices do NOT use standard MQTT/8883. They use a proprietary AES-encrypted protocol on TCP port 6668 and BROADCAST their presence on UDP 6666/6667 — use the `udp_listen` tool (port 6667) to find them. An MQTT broker on 8883 is NOT a Tuya device (it's likely Home Assistant / Mosquitto). To actually CONTROL a Tuya device you need its per-device `local_key`, which only comes from the Tuya cloud via Boss's developer account — so the right move is: discover them, then ASK Boss for the credentials/keys. Do NOT brute-force SSL against 8883.
