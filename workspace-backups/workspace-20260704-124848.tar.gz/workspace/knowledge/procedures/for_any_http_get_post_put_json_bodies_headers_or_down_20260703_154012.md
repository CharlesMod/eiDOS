---
id: for_any_http_get_post_put_json_bodies_headers_or_down_20260703_154012
category: procedures
tags:
- http
- requests
- post
- api
- tts
- tool
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
For ANY HTTP — GET, POST, PUT, JSON bodies, headers, or downloading binary (audio/images) — use the built-in `http_request` tool (aliases `fetch` / `http`), NOT the `requests` library. It is stdlib-based and always works; `import requests` inside a skill often fails because the skill runner lacks it (a trap you keep hitting). http_request returns JSON/text inline and auto-saves binary responses to a file. Example, downloading a camera snapshot in one call: http_request with method GET, url http://<device-ip>/snapshot.jpg, save=snap.jpg. (To talk, use the `speak` tool — NOT http_request to a TTS endpoint; speak also logs to the operator chat.) A plain GET is just url=...
