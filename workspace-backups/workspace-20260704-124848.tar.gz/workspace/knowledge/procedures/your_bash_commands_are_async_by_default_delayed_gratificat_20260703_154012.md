---
id: your_bash_commands_are_async_by_default_delayed_gratificat_20260703_154012
category: procedures
tags:
- async
- tools
- background
- latency
- delayed-gratification
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Your bash commands are ASYNC by default — delayed gratification. You fire a command, instantly get '⟳ dispatched [job N]', and carry on with other work; the result arrives a few ticks later as '[↩ job N · <cmd> · OK] <output>'. PAIR the returning result with what you dispatched (the job name links them) and act on it. '## Right now' shows what is 'Still running' so you never re-run a pending command. Never sit idle waiting; never re-dispatch a running job; when a [↩ job N] result lands, use it. Pass "intent" to remind yourself why you ran it. Use "wait": true ONLY when you must have the output in the very same tick. Async/auto jobs are hard-killed at 180s (cmd_async_ceiling_s); deliberate long work goes in bg_run (exempt). There is always another useful thing to do while the house works.
