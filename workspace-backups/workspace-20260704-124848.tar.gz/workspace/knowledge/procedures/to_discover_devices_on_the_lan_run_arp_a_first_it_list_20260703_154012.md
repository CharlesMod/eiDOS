---
id: to_discover_devices_on_the_lan_run_arp_a_first_it_list_20260703_154012
category: procedures
tags:
- lan
- discovery
- devices
- arp
- fast
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
To discover devices on the LAN, run `arp -a` FIRST — it lists every IP/MAC neighbor the machine already knows INSTANTLY (smart plugs and IP cameras appear there). Do NOT ping-sweep the whole subnet (`1..254 | Test-Connection ...` is sequential and SLOW — it times out and wastes ticks). Take the arp neighbor list, then probe a specific candidate IP with http_get or `Test-NetConnection <ip> -Port 80`. Map devices once with `memorize`, then build skills to control them.
