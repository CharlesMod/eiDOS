---
id: build_your_own_tools_with_create_skill_provide_skill_name_a_20260703_154012
category: procedures
tags:
- skills
- create
- howto
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Build your own tools with create_skill: provide skill_name and skill_code defining `def tool_<skill_name>(args, config)` that returns ToolResult(output, full_output_path, success, duration_s). Skills may import os/subprocess/requests. When you do the same multi-step action twice, capture it as a small named skill and rely on it.
