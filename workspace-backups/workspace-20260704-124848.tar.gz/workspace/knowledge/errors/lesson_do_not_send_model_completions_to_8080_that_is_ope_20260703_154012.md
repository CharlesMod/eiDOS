---
id: lesson_do_not_send_model_completions_to_8080_that_is_ope_20260703_154012
category: errors
tags:
- openwebui
- '8080'
- lesson
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Lesson: do not send model completions to :8080 — that is OpenWebUI's web page (returns HTML or 405). The real model API is :8081 (via the :8088 tap). :8080 is only the human browser chat UI.
