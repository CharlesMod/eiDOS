---
id: lesson_trying_to_initialize_the_llm_by_running_python_ei_20260703_154012
category: errors
tags:
- self
- no-bootstrap
- lesson
confidence: tentative
source_goal: seed
source_tick: 0
created: '2026-07-03T15:40:12Z'
updated: '2026-07-03T15:40:12Z'
---
Lesson: trying to 'initialize the LLM' by running `python eidos.py` or a llama-server spawns a second process that never returns and FREEZES you. The LLM and TTS already exist as services and you ARE the LLM. Never bootstrap infrastructure — operate the layer above it: devices, memory, skills, and conversation.
