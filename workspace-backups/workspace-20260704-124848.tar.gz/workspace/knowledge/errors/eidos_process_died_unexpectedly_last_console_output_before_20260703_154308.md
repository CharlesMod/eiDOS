---
id: eidos_process_died_unexpectedly_last_console_output_before_20260703_154308
category: errors
tags:
- crash
- watchdog
- recovery
confidence: tentative
source_goal: ''
source_tick: 0
created: '2026-07-03T15:43:08Z'
updated: '2026-07-03T15:43:08Z'
---
eiDOS process died unexpectedly. Last console output before death:
[eidos] Running crash recovery...
[eidos] Created initial plan.md
[eidos ✦ Lv.1 curious] Online. Lv.1 (0 XP) | 0 ticks | 0 goals | traits: developing
[eidos ✦ Lv.1 curious] Starting tick loop (interval=20.0s, mock=False)
[eidos ✦ Lv.1 curious] Waiting for an OpenAI-compatible LLM server at http://127.0.0.1:8080 ...
[eidos ✦ Lv.1 curious] LLM server reachable at http://127.0.0.1:8080/v1/models (waited 0s)
[eidos ✦ Lv.1 curious] nervous bus up (inproc); afferent + GPU arbiter + neuromod ready
[eidos ✦ Lv.1 curious] metabolism sta
