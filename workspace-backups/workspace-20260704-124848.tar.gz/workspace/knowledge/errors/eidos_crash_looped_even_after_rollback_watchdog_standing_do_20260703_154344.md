---
id: eidos_crash_looped_even_after_rollback_watchdog_standing_do_20260703_154344
category: errors
tags:
- crash
- watchdog
- recovery
confidence: tentative
source_goal: ''
source_tick: 0
created: '2026-07-03T15:43:44Z'
updated: '2026-07-03T15:43:44Z'
---
eiDOS crash-looped even after rollback. Watchdog standing down — needs operator attention.
