import os
print(f"Hostname: {os.uname().nodename}")
print(f"Uptime: {open('/proc/uptime').read().strip()}")